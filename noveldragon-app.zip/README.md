# NovelAI Reader — Android app

The NovelAI Reader generator page (offline library + silent AI forge, LitReader-style, fixed 510 layout, immersive) wrapped in a WebView, plus the native bridge. First launch needs no connection: the app opens its bundled page (app/src/main/assets/www/).

## Build the APK in the cloud (nothing to install)

1. Create a free GitHub account and a new empty repository.
2. Upload the contents of this folder (everything, keeping the structure: settings.gradle sits at the repo root, workflows under .github/workflows/).
3. Open the Actions tab → Build NovelAI Reader APK → the run starts by itself (or Run workflow). Wait ~5–10 minutes.
4. Download the noveldragon-apk artifact, copy it to the phone, tap to install (allow install unknown apps once).

All builds share one signing key (novdragon-debug.p12, committed in the repo — do not delete it), so every new APK installs over the old one as an update: no uninstall, and the library, training corpus and settings carry over. (A YueDu build is a different package and lives side by side — no conflict.)

## Updating the bundled page (new generator version, same install)

1. In the generator, open the More tab → Export standalone HTML.
2. In your repo, replace app/src/main/assets/www/index.html with the new file and commit. The workflow rebuilds by itself.
3. Download the new artifact and tap it on the phone. It installs as an update — same app, same data.

## What the wrapper gives the page

- Fixed 510 layout: wide viewport + overview mode + initial scale from the device width, so the layout stays at 510 CSS px on every screen.
- Sticky immersive fullscreen, edge-to-edge behind transparent system bars, force-dark light content (IMMERSIVE / EDGE_TO_EDGE / DARK_MODE manifest flags on; PULL_REFRESH and DESKTOP_SITE off).
- Portrait lock, double-back-press to exit, and the page hook window.__yueBackPressed (closes dialogs and sheets first).
- Native bridge (YueNative): device HTTP with custom headers, device voices for read-aloud, file export folder (Download/NovelAI/), bot-check screen. The page works fully without calling any of it.

## Play Store bundle (.aab)

The Build NovelAI Reader Bundle workflow builds app-release.aab (same key, so every rebuild uploads as an update of the last). Upload it in Play Console; Play App Signing re-signs for users with Google own key.

## Build locally (optional)

Android Studio → Open → this folder → let it sync → Run. Same APK.
